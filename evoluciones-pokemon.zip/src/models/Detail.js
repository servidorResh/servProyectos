
export class Detail {
  details = '';

  constructor(details) {
    this.details = details;
  }

}